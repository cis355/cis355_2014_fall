﻿**************************************************************
*        Generic Mobility Simulation Framework (GMSF)        *
**************************************************************

The Generic Mobility Simulation Framework (GMSF) was developed
by Philipp Sommer as a part of his master thesis [1] at 
ETH Zurich and has been presented at MobilityModels'08, the
first ACM SIGMOBILE workshop on Mobility models [2].

------------------------------------------------------------------------
 Mobility Models
------------------------------------------------------------------------

The simulation framework contains our new GIS-based mobility model,
the MMTS model and the common Random Waypoint and Manhattan models.

 * GIS-based mobility model: Steady-state random trips on real road
   topology from the Swiss geographic information system (GIS) [3].
   The model implements a basic car-following mechanism using the 
   Intelligent-Driver Model (IDM) [4]. Additionally, major road 
   intersections are controlled by a simple traffic light model.
   Mobility traces can be generated based on the road topology of
   three different areas in Switzerland (City, Urban and Rural scenario)
   
 * MMTS Model: Mobility model which is based on realistic vehicular
   traces and on the road topology from the Multi-agent Microscopic
   Traffic Simulator (MMTS) [5]. We provide vehicular traces for three
   different areas in Switzerland (City, Urban and Rural scenario).
   
 * Random Waypoint Model: Steady-state random trip model. The steady-state
   initialization is performed using the method described by Camp and Navidi. [6]
   
 * Manhattan Model: Nodes travel on a grid-like road network. If the
   distance to the front vehicle is below a threshold value, the speed
   is set at maximum to the speed of the front vehicle. Otherwise, nodes
   are accelerating or decelerating on a random basis while moving at a
   speed in the specified range.
   
 More details can be found in the thesis [1] or in the research paper [2]. 
 
------------------------------------------------------------------------
 Output Format
------------------------------------------------------------------------
 
Mobility traces can be generated in various output formats. GMSF supports
the mobility trace format of the popular ns-2 (incl. nam traces) and Qualnet
network simulators. In addition, we offer to generate traces in a simulator
independent XML-based trace format. 


-----------------------------------------------------------------------
 Usage
------------------------------------------------------------------------
1. Build GMSF:

$ ant build 

2. Run GMSF:

$ java -jar gmsf.jar <PARAMETERS>

where <PARAMETERS> is a set of comma-separated KEY=VALUE pairs:

INPUT_DIRECTORY=<directory containing input files>
OUTPUT_DIRECTORY=<output directory for trace files>
SIMULATION_SIZE=<size of the simulation area>
TIME=<simulation time in seconds>
SEED=<random seed value>
MODEL=<type of mobility model, valid values are RWP (Random Waypoint), MN (Manhattan), GIS (GIS-based), MMTS (MMTS traces), FIXED (no mobility)>
FORMAT=<output format for the mobility traces, valid values are QUALNET, NAM, NS-2, XML, PDF>
GUI=<1=enables/0=disables the graphical user interface>

------------------------------------------------------------------------
Examples:
------------------------------------------------------------------------

- Random Waypoint
$ java -jar gmsf.jar MODEL=RWP,SIMULATION_SIZE=1000,NODES=100,TIME=1000,FORMAT=NAM

- Manhattan
$ java -jar gmsf.jar MODEL=MN,SIMULATION_SIZE=1000,BLOCKS=10,NODES=100,TIME=1000,FORMAT=NAM
where BLOCKS=<number of blocks in one dimension>

- MMTS mobility
$ java -jar gmsf.jar MODEL=MMTS,SIMULATION_SIZE=3000,NODES=117,TIME=1000,INPUT_DIRECTORY=Rural/,FORMAT=NAM
where INPUT_DIRECTORY=<dir> specifies the directory where the corresponding MMTS traces file (mmts.dat) is located

- GIS based mobility model
$ java -jar gmsf.jar MODEL=GIS,CAR_FOLLOWING=1,TRAFFIC_LIGHTS=1,SIMULATION_SIZE=3000,NODES=100,TIME=2000,INPUT_DIRECTORY=Rural/,FORMAT=NAM
where INPUT_DIRECTORY=<dir> specifies the directory where the corresponding road topology file (roads.dat) is located
The CAR_FOLLOWING parameter specifies whether cars should respect a minimal distance to the car ahead. Cars do stop at larger intersections when the TRAFFIC_LIGHTS parameter is set to 1 (see the report for details).
 

------------------------------------------------------------------------
 References
------------------------------------------------------------------------
[1] "Design and Analysis of Realistic Mobility Model for Wireless Mesh Networks", Philipp Sommer, Master Thesis, ETH Zurich, Sept 07.
[2] "Generic mobility simulation framework (GMSF)", Rainer Baumann, Franck Legendre and Philipp Sommer, MobilityModels '08: Proceeding of the 1st ACM SIGMOBILE workshop on Mobility models, Hongkong, China.
[3] "VECTOR 25 - Landscape model of Switzerland", The Swiss Federal Office of Topography swisstopo
[4] "Congested Traffic States in Empirical Observations and Microscopic Simulations", M. Treiber , A. Hennecke and D. Helbing, Physical Review
[5] Realistic Vehicular Traces, Laboratory for Software Technology, ETH Zurich
[6] "Stationary Distributions for the Random Waypoint Mobility Model", W. Navidi and T. Camp, IEEE Transactions on Mobile Computing, Vol. 3, 2004
[7] "The IMPORTANT framework for analyzing the Impact of Mobility on Performance Of RouTing protocols for Adhoc NeTworks", F. Bai, N. Sadagopan and A. Helmy, INFOCOM 2003<!DOCTYPE html>
<!-- Server: sfn-web-10 -->


  












<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]>--> <html lang="en" class="no-js"> <!--<![endif]-->
  <head>
    <meta content="text/html; charset=UTF-8" http-equiv="content-type"/>
    <title>
  Generic Mobility Simulation Framework / Code /
  [r5]
  /README.txt
</title>
    
<meta id="webtracker" name="webtracker" content='{&#34;event_id&#34;: &#34;5451c21c-8ccc-11e4-8dcd-0200ac1d293c&#34;, &#34;project&#34;: &#34;gmsf&#34;, &#34;action_type&#34;: &#34;svn&#34;}' />

<script src="http://a.fsdn.com/allura/nf/1418835403/_ew_/theme/sftheme/js/sftheme/modernizr.custom.90514.js"></script>

<script src="http://a.fsdn.com/allura/nf/1418835403/_ew_/theme/sftheme/js/sftheme/jquery-1.8.0.min.js"></script>

<script src="http://a.fsdn.com/allura/nf/1418835403/_ew_/theme/sftheme/js/sftheme/header.js"></script>
<!--[if lt IE 7 ]>
  <script src="http://a.fsdn.com/allura/nf/1418835403/_ew_/theme/sftheme/js/sftheme/dd_belatedpng.js"></script>
  <script> DD_belatedPNG.fix('img, .png_bg'); //fix any <img> or .png_bg background-images </script>
<![endif]-->
<link href='//fonts.googleapis.com/css?family=Ubuntu:regular' rel='stylesheet' type='text/css'>
<style type="text/css">
    @font-face {
        font-family: "Pictos";
        src: url('http://a.fsdn.com/allura/nf/1418835403/_ew_/theme/sftheme/css/fonts/sftheme/pictos-web.eot');
        src: local("☺"), url('http://a.fsdn.com/allura/nf/1418835403/_ew_/theme/sftheme/css/fonts/sftheme/pictos-web.woff') format('woff'), url('http://a.fsdn.com/allura/nf/1418835403/_ew_/theme/sftheme/css/fonts/sftheme/pictos-web.ttf') format('truetype'), url('http://a.fsdn.com/allura/nf/1418835403/_ew_/theme/sftheme/css/fonts/sftheme/pictos-web.svg') format('svg');
    }
</style>
    <script type="text/javascript">
            /*jslint onevar: false, nomen: false, evil: true, css: true, plusplus: false, white: false, forin: true, on: true, immed: false */
            /*global confirm, alert, unescape, window, jQuery, $, net, COMSCORE */
    </script>
    
      <!-- ew:head_css -->

    
      <link rel="stylesheet"
                type="text/css"
                href="http://a.fsdn.com/allura/nf/1418835403/_ew_/_slim/css?href=allura%2Fcss%2Fforge%2Fhilite.css"
                >
    
      <link rel="stylesheet"
                type="text/css"
                href="/nf/tool_icon_css?1418835403"
                >
    
      <link rel="stylesheet"
                type="text/css"
                href="http://a.fsdn.com/allura/nf/1418835403/_ew_/theme/sftheme/css/forge.css"
                >
    
      
<!-- /ew:head_css -->

    
    
    
      <!-- ew:head_js -->

    
      
<!-- /ew:head_js -->

    
    

    
      <style type="text/css">
        #page-body.project---init-- #top_nav { display: none; }
#page-body.project---init-- #nav_menu_holder { display: none; margin-bottom: 0; }
#page-body.project---init-- #content_base {margin-top: 0; }
      </style>
    
    
    <link rel="alternate" type="application/rss+xml" title="RSS" href="/p/gmsf/code/feed.rss"/>
    <link rel="alternate" type="application/atom+xml" title="Atom" href="/p/gmsf/code/feed.atom"/>

      <style>.XJPBHpjfFjrxMyXVYnXbeg { display:none }</style>

    
    
    
    


<script type="text/javascript">
    var _gaq = _gaq || [];

    function _add_tracking(prefix, tracking_id, send_user) {
        _gaq.push([prefix+'._setAccount', tracking_id]);
        _gaq.push([prefix+'._setCustomVar', 1, 'Page Type', 'svn', 3]);_gaq.push([prefix+'._trackPageview']);
    }
      _add_tracking('sfnt1', 'UA-32013-6', true);
      _add_tracking('sfnt2', 'UA-36130941-1', true);
    

    (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' === document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();
</script>
  </head>

  <body id="forge">
    <h2 class="hidden">
        <span style="color:red">Error:</span> CSS did not load.<br>
        This may happen on the first request due to CSS mimetype issues.
        Try clearing your browser cache and refreshing.
        <hr>
    </h2>
    
    
      <!-- ew:body_top_js -->

    
      
<!-- /ew:body_top_js -->

    
    
    
<header id="site-header">
    <div class="wrapper">
        <a href="/" class="logo">
            <span>SourceForge</span>
        </a>
        
        <form method="get" action="/directory/">
            <input type="text" id="words" name="q" placeholder="Search">
        </form>
        
        <!--Switch to {language}-->
        <nav id="nav-site">
            <a href="/directory/" title="Browse our software.">Browse</a>
            <a href="/directory/enterprise" title="Browse our Enterprise software.">Enterprise</a>
            <a href="/blog/" title="Read the latest news from the SF HQ.">Blog</a>
            <a href="/support" title="Contact us for help and feedback.">Help</a>
            <a href="/jobs?source=header" title="Search 80k+ tech jobs." class="featured-link">Jobs</a>
        </nav>
        <nav id="nav-account">
            
              <div class="logged_out">
                <a href="/auth/">Log In</a>
                <span>or</span>
                <a href="https://sourceforge.net/user/registration/">Join</a>
              </div>
            
        </nav>
        
    </div>
</header>
<header id="site-sec-header">
    <div class="wrapper">
        <nav id="nav-hubs">
            <h4>Solution Centers</h4>
            <a href="http://goparallel.sourceforge.net/">Go Parallel</a>
            <a href="http://ibmsmarteritservices.sourceforge.net/">Smarter IT</a>
            <a href="http://ibmsoftwaredelivery.sourceforge.net/">Software Delivery</a>
            <a href="http://apmsolutions.sourceforge.net/">Performance</a>
            <a href="http://ibmsmarterdata.sourceforge.net/">Data Management</a>
        </nav>
        <nav id="nav-collateral">
            <a href="http://library.slashdotmedia.com/?source=sfnet_header">Resources</a>
            
            <a href="">Newsletters</a>
            
        </nav>
    </div>
</header>
    
    
    
    
    
    <section id="page-body" class=" neighborhood-Projects project-gmsf mountpoint-code">
	  <div id="nav_menu_holder">
            
            



    
    
    
    
    <nav id="breadcrumbs">
        <ul>
            <li itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a itemprop="url" href="/">Home</a></li>
            <li itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a itemprop="url" href="/directory">Browse</a></li>
            
            
                
            
            
            
                <li itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a itemprop="url" href="/p/">Projects</a></li>
                
            
            
                <li itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a itemprop="url" href="/p/gmsf/">Generic Mobility Simulation Framework</a></li>
                
            
            
                <li itemscope itemtype="http://data-vocabulary.org/Breadcrumb">Code</li>
                
            
        </ul>
    </nav>
    
    
  
    
    
  
  
    
    <h1 class="project_title">
        <a href="/p/gmsf/" class="project_link">Generic Mobility Simulation Framework</a>
    </h1>
    
    
    
    <span id="dev-status" class="beta">beta</span>
    
    <h2 class="project_summary">
        
    </h2>
    
    <div class="brought-by">
        Brought to you by:
        
        
            
                <a href="/u/phsommer/">phsommer</a>
            </div>
    

            
      </div>
      <div id="top_nav" class="">
        
        
<ul class="dropdown">
  
    <li class="">
        <a href="/projects/gmsf/" class="ui-icon-tool-summary-32">
            Summary
        </a>
        
        
    </li>
	
    <li class="">
        <a href="/projects/gmsf/files/" class="ui-icon-tool-files-32">
            Files
        </a>
        
        
    </li>
	
    <li class="">
        <a href="/projects/gmsf/reviews" class="ui-icon-tool-reviews-32">
            Reviews
        </a>
        
        
    </li>
	
    <li class="">
        <a href="/projects/gmsf/support" class="ui-icon-tool-support-32">
            Support
        </a>
        
        
    </li>
	
    <li class="">
        <a href="/p/gmsf/wiki/" class="ui-icon-tool-wiki-32">
            Wiki
        </a>
        
        
    </li>
	
    <li class="selected">
        <a href="/p/gmsf/code/" class="ui-icon-tool-svn-32">
            Code
        </a>
        
        
    </li>
	
</ul>

        
      </div>
      <div id="content_base">
      
			  
			    
          


<div id="sidebar">
  
    <div>&nbsp;</div>
  
    
    
      
        
    
      <ul class="sidebarmenu">
      
    
    <li>
      <a href="/p/gmsf/code/commit_browser"><b data-icon="o" class="ico ico-folder"></b> <span>Browse Commits</span></a>
    </li>
  
      
    
    
      </ul>
      
    
    
</div>
          
          
			  
			  
          
        
        <div class="grid-20 pad">
          <h2 class="dark title">
<a href="/p/gmsf/code/5/">[r5]</a>:

  
  
 README.txt

            <!-- actions -->
            <small>
            

    
    <a id="maximize-content" href="#">
      <b data-icon="`" class="ico ico-expand" title="Maximize"> </b> Maximize
    </a>
    <a id="restore-content" href="#">
      <b data-icon="J" class="ico ico-restore" title="Restore"> </b> Restore
    </a>
<a href="/p/gmsf/code/5/log/?path=/README.txt">
  <b data-icon="N" class="ico ico-history" title="History"> </b> History
</a>

            </small>
            <!-- /actions -->
          </h2>
		
          <div>
            
  

            
  
    <p><a href="?format=raw">Download this file</a></p>
    <div class="clip grid-19 codebrowser">
      <h3>
        <span class="ico-l"><b data-icon="n" class="ico ico-table"></b> README.txt</span>
        &nbsp;&nbsp;
        104 lines (79 with data), 5.6 kB
      </h3>
      
        <table class="codehilitetable"><tbody><tr><td class="linenos"><div class="linenodiv"><pre>  1
  2
  3
  4
  5
  6
  7
  8
  9
 10
 11
 12
 13
 14
 15
 16
 17
 18
 19
 20
 21
 22
 23
 24
 25
 26
 27
 28
 29
 30
 31
 32
 33
 34
 35
 36
 37
 38
 39
 40
 41
 42
 43
 44
 45
 46
 47
 48
 49
 50
 51
 52
 53
 54
 55
 56
 57
 58
 59
 60
 61
 62
 63
 64
 65
 66
 67
 68
 69
 70
 71
 72
 73
 74
 75
 76
 77
 78
 79
 80
 81
 82
 83
 84
 85
 86
 87
 88
 89
 90
 91
 92
 93
 94
 95
 96
 97
 98
 99
100
101
102
103</pre></div></td><td class="code"><div class="codehilite"><pre><span id="l1" class="code_block">**************************************************************
</span><span id="l2" class="code_block">*        Generic Mobility Simulation Framework (GMSF)        *
</span><span id="l3" class="code_block">**************************************************************
</span><span id="l4" class="code_block">
</span><span id="l5" class="code_block">The Generic Mobility Simulation Framework (GMSF) was developed
</span><span id="l6" class="code_block">by Philipp Sommer as a part of his master thesis [1] at 
</span><span id="l7" class="code_block">ETH Zurich and has been presented at MobilityModels'08, the
</span><span id="l8" class="code_block">first ACM SIGMOBILE workshop on Mobility models [2].
</span><span id="l9" class="code_block">
</span><span id="l10" class="code_block">------------------------------------------------------------------------
</span><span id="l11" class="code_block"> Mobility Models
</span><span id="l12" class="code_block">------------------------------------------------------------------------
</span><span id="l13" class="code_block">
</span><span id="l14" class="code_block">The simulation framework contains our new GIS-based mobility model,
</span><span id="l15" class="code_block">the MMTS model and the common Random Waypoint and Manhattan models.
</span><span id="l16" class="code_block">
</span><span id="l17" class="code_block"> * GIS-based mobility model: Steady-state random trips on real road
</span><span id="l18" class="code_block">   topology from the Swiss geographic information system (GIS) [3].
</span><span id="l19" class="code_block">   The model implements a basic car-following mechanism using the 
</span><span id="l20" class="code_block">   Intelligent-Driver Model (IDM) [4]. Additionally, major road 
</span><span id="l21" class="code_block">   intersections are controlled by a simple traffic light model.
</span><span id="l22" class="code_block">   Mobility traces can be generated based on the road topology of
</span><span id="l23" class="code_block">   three different areas in Switzerland (City, Urban and Rural scenario)
</span><span id="l24" class="code_block">   
</span><span id="l25" class="code_block"> * MMTS Model: Mobility model which is based on realistic vehicular
</span><span id="l26" class="code_block">   traces and on the road topology from the Multi-agent Microscopic
</span><span id="l27" class="code_block">   Traffic Simulator (MMTS) [5]. We provide vehicular traces for three
</span><span id="l28" class="code_block">   different areas in Switzerland (City, Urban and Rural scenario).
</span><span id="l29" class="code_block">   
</span><span id="l30" class="code_block"> * Random Waypoint Model: Steady-state random trip model. The steady-state
</span><span id="l31" class="code_block">   initialization is performed using the method described by Camp and Navidi. [6]
</span><span id="l32" class="code_block">   
</span><span id="l33" class="code_block"> * Manhattan Model: Nodes travel on a grid-like road network. If the
</span><span id="l34" class="code_block">   distance to the front vehicle is below a threshold value, the speed
</span><span id="l35" class="code_block">   is set at maximum to the speed of the front vehicle. Otherwise, nodes
</span><span id="l36" class="code_block">   are accelerating or decelerating on a random basis while moving at a
</span><span id="l37" class="code_block">   speed in the specified range.
</span><span id="l38" class="code_block">   
</span><span id="l39" class="code_block"> More details can be found in the thesis [1] or in the research paper [2]. 
</span><span id="l40" class="code_block"> 
</span><span id="l41" class="code_block">------------------------------------------------------------------------
</span><span id="l42" class="code_block"> Output Format
</span><span id="l43" class="code_block">------------------------------------------------------------------------
</span><span id="l44" class="code_block"> 
</span><span id="l45" class="code_block">Mobility traces can be generated in various output formats. GMSF supports
</span><span id="l46" class="code_block">the mobility trace format of the popular ns-2 (incl. nam traces) and Qualnet
</span><span id="l47" class="code_block">network simulators. In addition, we offer to generate traces in a simulator
</span><span id="l48" class="code_block">independent XML-based trace format. 
</span><span id="l49" class="code_block">
</span><span id="l50" class="code_block">
</span><span id="l51" class="code_block">-----------------------------------------------------------------------
</span><span id="l52" class="code_block"> Usage
</span><span id="l53" class="code_block">------------------------------------------------------------------------
</span><span id="l54" class="code_block">1. Build GMSF:
</span><span id="l55" class="code_block">
</span><span id="l56" class="code_block">$ ant build 
</span><span id="l57" class="code_block">
</span><span id="l58" class="code_block">2. Run GMSF:
</span><span id="l59" class="code_block">
</span><span id="l60" class="code_block">$ java -jar gmsf.jar &lt;PARAMETERS&gt;
</span><span id="l61" class="code_block">
</span><span id="l62" class="code_block">where &lt;PARAMETERS&gt; is a set of comma-separated KEY=VALUE pairs:
</span><span id="l63" class="code_block">
</span><span id="l64" class="code_block">INPUT_DIRECTORY=&lt;directory containing input files&gt;
</span><span id="l65" class="code_block">OUTPUT_DIRECTORY=&lt;output directory for trace files&gt;
</span><span id="l66" class="code_block">SIMULATION_SIZE=&lt;size of the simulation area&gt;
</span><span id="l67" class="code_block">TIME=&lt;simulation time in seconds&gt;
</span><span id="l68" class="code_block">SEED=&lt;random seed value&gt;
</span><span id="l69" class="code_block">MODEL=&lt;type of mobility model, valid values are RWP (Random Waypoint), MN (Manhattan), GIS (GIS-based), MMTS (MMTS traces), FIXED (no mobility)&gt;
</span><span id="l70" class="code_block">FORMAT=&lt;output format for the mobility traces, valid values are QUALNET, NAM, NS-2, XML, PDF&gt;
</span><span id="l71" class="code_block">GUI=&lt;1=enables/0=disables the graphical user interface&gt;
</span><span id="l72" class="code_block">
</span><span id="l73" class="code_block">------------------------------------------------------------------------
</span><span id="l74" class="code_block">Examples:
</span><span id="l75" class="code_block">------------------------------------------------------------------------
</span><span id="l76" class="code_block">
</span><span id="l77" class="code_block">- Random Waypoint
</span><span id="l78" class="code_block">$ java -jar gmsf.jar MODEL=RWP,SIMULATION_SIZE=1000,NODES=100,TIME=1000,FORMAT=NAM
</span><span id="l79" class="code_block">
</span><span id="l80" class="code_block">- Manhattan
</span><span id="l81" class="code_block">$ java -jar gmsf.jar MODEL=MN,SIMULATION_SIZE=1000,BLOCKS=10,NODES=100,TIME=1000,FORMAT=NAM
</span><span id="l82" class="code_block">where BLOCKS=&lt;number of blocks in one dimension&gt;
</span><span id="l83" class="code_block">
</span><span id="l84" class="code_block">- MMTS mobility
</span><span id="l85" class="code_block">$ java -jar gmsf.jar MODEL=MMTS,SIMULATION_SIZE=3000,NODES=117,TIME=1000,INPUT_DIRECTORY=Rural/,FORMAT=NAM
</span><span id="l86" class="code_block">where INPUT_DIRECTORY=&lt;dir&gt; specifies the directory where the corresponding MMTS traces file (mmts.dat) is located
</span><span id="l87" class="code_block">
</span><span id="l88" class="code_block">- GIS based mobility model
</span><span id="l89" class="code_block">$ java -jar gmsf.jar MODEL=GIS,CAR_FOLLOWING=1,TRAFFIC_LIGHTS=1,SIMULATION_SIZE=3000,NODES=100,TIME=2000,INPUT_DIRECTORY=Rural/,FORMAT=NAM
</span><span id="l90" class="code_block">where INPUT_DIRECTORY=&lt;dir&gt; specifies the directory where the corresponding road topology file (roads.dat) is located
</span><span id="l91" class="code_block">The CAR_FOLLOWING parameter specifies whether cars should respect a minimal distance to the car ahead. Cars do stop at larger intersections when the TRAFFIC_LIGHTS parameter is set to 1 (see the report for details).
</span><span id="l92" class="code_block"> 
</span><span id="l93" class="code_block">
</span><span id="l94" class="code_block">------------------------------------------------------------------------
</span><span id="l95" class="code_block"> References
</span><span id="l96" class="code_block">------------------------------------------------------------------------
</span><span id="l97" class="code_block">[1] "Design and Analysis of Realistic Mobility Model for Wireless Mesh Networks", Philipp Sommer, Master Thesis, ETH Zurich, Sept 07.
</span><span id="l98" class="code_block">[2] "Generic mobility simulation framework (GMSF)", Rainer Baumann, Franck Legendre and Philipp Sommer, MobilityModels '08: Proceeding of the 1st ACM SIGMOBILE workshop on Mobility models, Hongkong, China.
</span><span id="l99" class="code_block">[3] "VECTOR 25 - Landscape model of Switzerland", The Swiss Federal Office of Topography swisstopo
</span><span id="l100" class="code_block">[4] "Congested Traffic States in Empirical Observations and Microscopic Simulations", M. Treiber , A. Hennecke and D. Helbing, Physical Review
</span><span id="l101" class="code_block">[5] Realistic Vehicular Traces, Laboratory for Software Technology, ETH Zurich
</span><span id="l102" class="code_block">[6] "Stationary Distributions for the Random Waypoint Mobility Model", W. Navidi and T. Camp, IEEE Transactions on Mobile Computing, Vol. 3, 2004
</span><span id="l103" class="code_block">[7] "The IMPORTANT framework for analyzing the Impact of Mobility on Performance Of RouTing protocols for Adhoc NeTworks", F. Bai, N. Sadagopan and A. Helmy, INFOCOM 2003
</span></pre></div></td></tr></tbody></table>
      
    </div>
  

          </div>
			
          
        </div>
      
      </div>
    </section>
      
<footer id="site-footer">
    <div class="wrapper">
        <nav>
            <h5>SourceForge</h5>
            <a href="/about">About</a>
            <a href="/blog/category/sitestatus/">Site Status</a>
            <a href="http://twitter.com/sfnet_ops">@sfnet_ops</a>
            <a id="allura-notice" href="https://forge-allura.apache.org/p/allura/">Powered by Allura</a>
        </nav>
        <nav>
            <h5>Find and Develop Software</h5>
            <a href="/create/">Create a Project</a>
            <a href="/directory/">Software Directory</a>
            <a href="/top">Top Downloaded Projects</a>
        </nav>
        <nav>
            <h5>Community</h5>
            <a href="/blog/">Blog</a>
            <a href="http://twitter.com/sourceforge">@sourceforge</a>
            <a href="/jobs?source=footer">Job Board</a>
            <a href="http://library.slashdotmedia.com/?source=sfnet_footer">Resources</a>
        </nav>
        <nav>
            <h5>Help</h5>
            <a href="http://p.sf.net/sourceforge/docs">Site Documentation</a>
            <a href="/support">Support Request</a>
            <a href="http://p.sf.net/sourceforge/irc">Real-Time Support</a>
        </nav>
    </div>
</footer>
<footer id="site-copyright-footer">
    <div class="wrapper">
        <div id="copyright">
            Copyright &copy; 2014 SourceForge. All Rights Reserved.<br />
            SourceForge is a <a href="http://www.diceholdingsinc.com/phoenix.zhtml?c=211152&amp;p=irol-landing">Dice Holdings, Inc.</a> company.
        </div>
        <nav>
            <a href="http://slashdotmedia.com/terms-of-use">Terms</a>
            <a href="http://slashdotmedia.com/privacy-statement/">Privacy</a>
            <span id='teconsent'></span>
            <a href="http://slashdotmedia.com/opt-out-choices">Opt Out Choices</a>
            <a href="http://slashdotmedia.com">Advertise</a>
            <a href="http://sourceforge.jp/">SourceForge.JP</a>
        </nav>
    </div>
</footer>
    <div id="messages">
        
    </div>
    
    
      <!-- ew:body_js -->

    
      <script type="text/javascript" src="http://a.fsdn.com/allura/nf/1418835403/_ew_/_slim/js?href=allura%2Fjs%2Fjquery-base.js%3Ballura%2Fjs%2Fjquery.notify.js%3Ballura%2Fjs%2Fmodernizr.js%3Ballura%2Fjs%2Fsylvester.js%3Ballura%2Fjs%2Fpb.transformie.min.js%3Ballura%2Fjs%2Fallura-base.js%3Ballura%2Fjs%2Fmaximize-content.js"></script>
    
      
<!-- /ew:body_js -->

    
    
      <!-- ew:body_js_tail -->

    
      
<!-- /ew:body_js_tail -->

    
    

<script type="text/javascript">(function() {
  $('#access_urls .btn').click(function(evt){
    evt.preventDefault();
    var parent = $(this).parents('.btn-bar');
    $(parent).find('input').val($(this).attr('data-url'));
    $(parent).find('span').text($(this).attr('title')+' access');
    $(this).parent().children('.btn').removeClass('active');
    $(this).addClass('active');
  });
  $('#access_urls .btn').first().click();

  
  var repo_status = document.getElementById('repo_status');
  // The repo_status div will only be present if repo.status != 'ready'
  if (repo_status) {
    $('.spinner').show()
    function check_status() {
        $.get('/p/gmsf/code/status', function(data) {
            if (data.status === 'ready') {
                window.clearInterval(status_checker);
                $('.spinner').hide()
                $('#repo_status h2').html('Repo status: ready. <a href=".">Click here to refresh this page.</a>');
            }
            else {
                $('#repo_status h2 span').html(data.status);
            }
        });
    }
    // Check repo status every 15 seconds
    var status_checker = window.setInterval(check_status, 15000);
    
  }
}());
</script>

<script type="text/javascript">(function() {
  $(window).bind('hashchange', function(e) {
    var hash = window.location.hash.substring(1);
	if ('originalEvent' in e && 'oldURL' in e.originalEvent) {
      $('#' + e.originalEvent.oldURL.split('#')[1]).css('background-color', 'transparent');
	}
    if (hash !== '' && hash.substring(0, 1) === 'l' && !isNaN(hash.substring(1))) {
      $('#' + hash).css('background-color', '#ffff99');
    }
  }).trigger('hashchange');

  var clicks = 0;
  $('.code_block').each(function(index, element) {
    $(element).bind('click', function() {
      // Trick to ignore double and triple clicks
      clicks++;
      if (clicks == 1) {
        setTimeout(function() {
          if (clicks == 1) {
            var hash = window.location.hash.substring(1);
            if (hash !== '' && hash.substring(0, 1) === 'l' && !isNaN(hash.substring(1))) {
              $('#' + hash).css('background-color', 'transparent');
            }
            $(element).css('background-color', '#ffff99');
            window.location.href = '#' + $(element).attr('id');
          };
          clicks = 0;
        }, 500);
      };
    });
  });
}());
</script>

    
      
    
    
   
    <script src="//s.fsdn.com/con/js/webtracker.js" type="text/javascript"></script>
    <!-- Google Code for Remarketing tag -->
    <!-- Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. For instructions on adding this tag and more information on the above requirements, read the setup guide: google.com/ads/remarketingsetup -->
    <script type="text/javascript">
        /* <![CDATA[ */
        var google_conversion_id = 1002083962;
        var google_conversion_label = "G_uGCOaBlAQQ-qzq3QM";
        var google_custom_params = window.google_tag_params;
        var google_remarketing_only = true;
        /* ]]> */
    </script>
    <script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js"> </script>
    <script type="text/javascript" src='//consent-st.truste.com/get?name=notice.js&domain=slashdot.org&c=teconsent&text=true'></script>
    <noscript>
      <div style="display:inline;">
        <img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/1002083962/?value=0&amp;label=G_uGCOaBlAQQ-qzq3QM&amp;guid=ON&amp;script=0"/>
      </div>
    </noscript>
    
  </body>
</html>