<?php

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<style>
	@font-face {
		font-family: Quicksand;
		src: url("Quicksand-Regular.otf") format("opentype");
	}
	@font-face {
		font-family: QuicksandBold;
		src: url("Quicksand-Bold.otf") format("opentype");
	}
	</style>
	<title>untitled</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="generator" content="Geany 1.23.1" />
	<script src="ckeditor/ckeditor.js"></script>
</head>
<body style="font-family: Quicksand; height: 100%;">
	<div style="box-shadow: 2px 2px 5px #888888; float: left; width: 100%; background-color: #9ADF85; vertical-align: middle; border: 2px solid black; border-radius: 10px; font-size: 64px; font-family: QuicksandBold;">
		<div style="float:left; padding-left: 10px;">EzLearn LMS</div><div style="float: right;"><img src="book.png" style="width: 80px; vertical-align: middle; padding-right:20px;"></div>
	</div>
	
	<div style="float: left; font-family: QuicksandBold; font-size: 25px; width: 100%; text-align: center;">
		<a href="home.php"><div style="box-shadow: 5px 5px 5px #888888; color: #155D4F; float: left; width: 18%; border: 2px solid #406C63; border-radius: 5px; background-color: #77C7B7; margin: 7px;">Home</div></a> 
		<a href="assignments.php"><div style="box-shadow: 5px 5px 5px #888888; color: #155D4F; float: left; width: 18%; border: 2px solid #406C63; border-radius: 5px; background-color: #77C7B7; margin: 7px;">Assignments</div></a>
		<a href="resources.php"><div style="box-shadow: 5px 5px 5px #888888; color: #155D4F; float: left; width: 18%; border: 2px solid #406C63; border-radius: 5px; background-color: #77C7B7; margin: 7px;">Resources</div></a> 
		<a href="#"><div style="box-shadow: 5px 5px 5px #888888; color: #155D4F; float: left; width: 18%; border: 2px solid #406C63; border-radius: 5px; background-color: #77C7B7; margin: 7px;">Disscussions</div></a> 
		<a href="#"><div style="box-shadow: 5px 5px 5px #888888; color: #155D4F; float: left; width: 18%; border: 2px solid #406C63; border-radius: 5px; background-color: #77C7B7; margin: 7px;">Grades</div></a> 
	</div>';

?>
